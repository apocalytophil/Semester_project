#include <iostream>
using namespace std;

class student{
	public:
		string name;
		string contact;
		string email;
		int level;
		double gpa;
		string index;
};
class List{
	public:
		string index;
		int level;
};

int main() {
	int option;
	student detail[10000];
	int total_student = 4;

	int level,gpa;
	string index,email;
	string name,contact;
	List attendance[10000];
	
	detail[0]={"Sonia","0551447527","ankph@uenr.edu",100,3.72,"UEB3230022"};
	detail[1]={"eDiara","0544560943","diara@uenr.edu",200,4.0,"UEB2303336"};
	detail[2]={"Sir. Kind","0201236742","kind@uenr.edu",400,3.67},"UEB3267894";
	detail[3]={"Sophas","0500978294","sophas@uenr.edu",100,2.62,"UEB3234567"};

	
	start:
	cout<<"\n------------------ SCHOOL MANAGEMENT SYSTEM ---------------------"
	    
		"\n---------------------------------------------------------------\n"
	    
		"\n1. Check total number student"
	    "\n2. Mark attendance"
	    "\n3. View all Details"
	    "\n4. Add new student"
		"\n5. Quit       Select : ";
	   
	    cin>>option;
	    
	    if(option==1){
	     
	    		cout<<"The total number of students are : "<<total_student<<"\n\n\n"
				"Do you want to see the details of the students??"
				"\n\n\n 1. Yes \n 2. No \n     Select : ";
				cin>>option;
				if(option ==1){
					goto profiles;
				}else if(option == 2){
					goto start;
				}else{
					cout<<"Incorrect Input";
					
				}
	    		
	    	}else if(option==2){
	    	
	    	
	    		option =0;
	    		cout<<"--------------ATTENDANCE--------------\n";
				while(option!=2){
					int count;
					attend:
					cout<<"Index : ";
					cin>>index;
					cout<<"Level [100 - 400]:";
					cin>>level;
					attendance[count].index=index;
					attendance[count].level=level;
					
					cout<<"Is time up??\n 1. Yes\n2. No\n    select : ";
					cin>>option;
					if(option==1){
						cout<<"   INDEX    ------   LEVEL\n\n";
						for(int i=0;i<=count;i++){
							
							cout<<attendance[i].index<<"    "<<attendance[i].level;
						
						}break;
					}else{
					goto attend;
					}
					count++;
				}	
	    }else if(option==3){
	    	
	    	
	    		system("cls");
	    		profiles:
	    			cout<<"Name           Mail        Contact      GPA     Index     Level"<<endl;
	    			
	    		for(int i=0;i<=total_student;i++){
	    			cout<<detail[i].name<<"    "<<detail[i].email<<"    "<<detail[i].contact<<"    "<<detail[i].gpa<<"    "<<detail[i].index<<"    "<<detail[i].level<<endl;
	    			
				}	
				
				cout<<"\n\n------------------------------apocalyto-------------------------------\n\n";
						goto start;
	    }else if(option==4){
	    	
	    		system("cls");
	    		cout<<"\n\n-------------------- ADD NEW STUDENTS ----------------------\n\n";
	    		
	    		cout<<"Enter First name : ";
	    		cin>>name;
	    		cout<<"Enter index : ";
	    		cin>>index;
	    		cout<<"Enter contact : ";
	    		cin>>contact;
				cout<<"Enter email : ";
	    		cin>>email;
	    		level =100;
	    		gpa = 0.0;
	    		total_student+=1;
	    		detail[total_student-1].name=name;
	    		detail[total_student-1].index=index;
	    		detail[total_student-1].contact=contact;
	    		detail[total_student-1].email=email;
	    		detail[total_student-1].level=level;
	    		detail[total_student-1].gpa=gpa;
	    			system("cls");
	    			int i = total_student-1;
	    		cout<<"------------ new student added --------\n\a";
	    		cout<<detail[i].name<<"  "<<detail[i].email<<" "<<detail[i].contact<<detail[i].gpa<<" "<<detail[i].index<<endl;
	    			goto start;
	    	}else if(option==5){
	    	
	    		system("cls");
	    		cout<<"\n\n\n\n\n ---------------------- QUIT ------------------------\a"
	    		
	    		"\n apocalyto ----------1-----0-----7--------- ";
	    		return 0;
	    	
			}else{
				system("cls");
				cout<<"incorrect option\a\a\a";
				goto start;
			}
	      	    
	
	   	    
		return 0;
}
